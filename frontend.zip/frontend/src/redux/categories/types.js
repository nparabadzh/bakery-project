export const CategoriesActionTypes = {
  SET_CATEGORIES: 'SET_CATEGORIES',
};
